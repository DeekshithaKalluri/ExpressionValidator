


/**********************************************
* Name: Christian Rottinghaus *
* Date: 02/07/2025*
* Assignment: Project 1 - Sequence and Order validation *
***********************************************
* Program takes the input of a file with different *
* chars. Reads each line and determines of the line is correct or not *
***********************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int loadData(FILE *fp);
int validation(char[]);
int push(char x);
char pop();
char peek();
char stack[30];
/**********************************************
* Description: Main function calls loadData function*
* Input:void *
* Output: no out put*
***********************************************/
int main(){
FILE *fp = NULL;
fp = fopen("expressions.txt","r");
if(fp == 0){
printf("Error opening the file\n");
exit(0);
}
loadData(fp);
}
/**********************************************
* Description: Reads file and loops thorugh file*
* Input:void *
* Output: if sucessful or not*
***********************************************/
int loadData(FILE *fp) {
int numLines;
char line[30];
fscanf(fp,"%d", &numLines);
//printf("%d", numLines);
//Loops through File
while(fscanf(fp,"%s", line) !=EOF){
//Emptys stack
for(int i = 0; i<strlen(stack); i++){
stack[i] = '\0';
}
validation(line);
}
}
/**********************************************
* Description: Validates line if it is correct or not*
* Input:Line being validated *
* Output: If line is correct or not*
***********************************************/
int validation(char line[]){
int len = strlen(line);
for(int i=0; i<len; i++){
if(i == 0) {
push(line[i]);
}
else{
char symbol = line[i];
switch(symbol){
case '}':
if(peek() == '{'){pop();}
break;
case ']':
if(peek() == '['){pop();}
break;
case ')':
if(peek() == '('){pop();}
break;
default:
// printf("%c\n", symbol);
if(symbol =='{' ||symbol == '[' || symbol =='(' || symbol ==')'
|| symbol ==']' || symbol =='}'|| symbol =='\0'){
push(line[i]);
}
else{
printf("Invalid character in expressons: %c\n", symbol);
return(0);
}
}
}
}
if(stack[0] != '\0'){printf("%s---> incorrect\n", line);}
else{printf("%s--->correct\n", line);}
}
/**********************************************
* Description: Pushes char to stack*
* Input:Char to push *
* Output: if sucessful or not*
***********************************************/
int push(char x){
char *ptr = stack;
for(; ptr<stack+30; ptr++){
if(*ptr== '\0'){
*ptr = x;
return(0);
}
}
return(0);
}
/**********************************************
* Description: Removes top char on stack*
* Input:void *
* Output: Char being poped*
***********************************************/
char pop(){
char * ptr = stack;
int size = sizeof(stack);
for(; ptr<stack+30; ptr++){
if(*ptr == '\0'){
ptr--;
char z = *ptr;
*ptr = '\0';
return z;
}
}
return('\0');
}
/**********************************************
* Description: Returns top element on stack*
* Input:void *
* Output: Top element on the stack*
***********************************************/
char peek(){
char * ptr = stack;
int size = sizeof(stack);
for(; ptr<stack+30; ptr++){
if(*ptr == '\0'){
ptr--;
return *ptr;
}
}
return('\0');
}
